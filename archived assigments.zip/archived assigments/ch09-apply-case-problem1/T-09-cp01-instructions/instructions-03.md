**Task 1**: When you have completed the assignment, check this task, open the task list and submit your work to your instructor.
