# Summary

**Rhetoric in the United States** -  Professor Annie Cho teaches rhetoric and history at White Sands College. She has asked for your help in designing a companion website for her course. The page you will work on contains portions of the inaugural address delivered by President John F. Kennedy in 1961. She has obtained a video excerpt of the speech that she wants you to augment with captions. A preview of the page you will create is shown in *Figure 8–64*.

![A homepage preview of “Rhetoric in the United States” website. The page displays a video grab of the president John F. Kennedy delivering a speech. ](https://cdn.filestackcontent.com/rf973cGSW2KvmFm2T8h1)
<sup>*Figure 8-64*</sup>

