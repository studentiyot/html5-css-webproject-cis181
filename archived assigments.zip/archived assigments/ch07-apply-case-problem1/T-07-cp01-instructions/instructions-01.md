# Summary

**ACGIP Conference** - Professor Darshan Banerjee is the project coordinator for the annual conference of the Association of Computer Graphics and Image Processing (ACGIP), which takes place this year in Sante Fe, New Mexico. Darshan has asked you to work on the conference’s website, starting with the registration form for conference attendees. The initial form will collect contact information for people attending the conference. *Figure 7–65* shows a preview of the form you will create for Darshan.

![A screenshot of a webpage displays a registration form for the A C G I P Conference. ](https://cdn.filestackcontent.com/5FPwXLaTeyhgf47nbiNA)
<sup>*Figure 7-65*</sup>

Professor Banerjee has already written the HTML code for the page and the styles for the form elements. He wants you to write the HTML code for the web form and the CSS validation styles. 
