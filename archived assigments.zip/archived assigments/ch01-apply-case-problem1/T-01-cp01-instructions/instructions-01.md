# Summary
**Jedds Tree Care** - Carol Jedds is the owner and operator of Jedds Tree Care and tree removal and landscaping company in Lansing, Michigan. She has asked for your help in developing her company’s website. She has already written some of the text for a few sample pages and wants you to write the HTML code. *Figure 1–51* shows a preview of the company’s home page that you’ll create.

![A home page preview of Jedds tree care. Two navigation links, home, and services are present at the top right of the page. A pane at the left, displays a section with the heading, Comments. Below the heading, three reviewers’ comments including the text of the quote and the name of the review are displayed. An image is displayed at the right with the title, Jedds Tree Care which is followed by two descriptive paragraphs. The contact information of Jedds Tree Care including address, email address, and phone number are displayed at the bottom of the page. ](https://cdn.filestackcontent.com/ccWbBmwQSheSHXyVeTM7)
<sup>*Figure 1-51*</sup>


The style sheets and graphic files have already been created for you. Your job is to write the HTML markup. 