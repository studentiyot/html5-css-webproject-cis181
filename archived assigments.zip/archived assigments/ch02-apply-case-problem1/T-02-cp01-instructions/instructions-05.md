# Description List Styles

Randall has put the author and the director of each play within a description list. Format these description lists now by going to the "Description List Styles" section and creating a style rule for the `dt` element that sets the font size to **1.3em**, the font weight to **bold**, and the font color to the semi-transparent value **hsla(0, 0%, 0%, 0.4)**.

Create a style rule for every `dd` element to set the font size to **1.3em**, the left margin space to **0** pixels, and the bottom margin space to **10** pixels.
