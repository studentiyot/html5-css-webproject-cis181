# Summary

**Philip Henslowe** - Classic Theatre Randall Chen is the media director for the Philip Henslowe Classic Theatre, a regional classical theatre in Coeur d’Alene, Idaho. You’ve been asked to work on the website design for the company. The first page you’ll manage lists the plays for next summer’s repertoire. A preview of the page is shown in *Figure 2–59*.

![A screenshot displays the list of plays at the Philip Henslowe Classic Theater. Six navigation links, home, plays, ticket, calendar, about P H C T, support are present at the top of the page. The list of plays is displayed with a navigation bar along with the content of the plays. ](https://cdn.filestackcontent.com/U9n3nTLaSatGqoVeH1e0)
<sup>*Figure 2-59*</sup>

The content and layout of the page has already been created for you. Your job will be to create a style sheet for the typography of the page. 